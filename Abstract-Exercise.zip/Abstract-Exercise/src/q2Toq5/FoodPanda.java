package q2Toq5;
import java.util.*;

public class FoodPanda {
	static void picker(String item){
		if(ChineseR.check(item)>0)
		{
			ChineseR.getInstance().bill(ChineseR.check(item),item);
		}
		else if(NorthIndianR.check(item)>0){
			NorthIndianR.getInstance().bill(NorthIndianR.check(item),item);
		}
		else if(SouthIndianR.check(item)>0){
			SouthIndianR.getInstance().bill(SouthIndianR.check(item),item);
		}
		else{
			System.out.println("Reorder : Food Item not Available");
		}
	}

	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Food Item");
		picker(sc.nextLine());

	}

}
abstract class Restaurant
{
	
	public String name;
	public long phone;
	void bill(int amnt,String item)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Name");
		String cname=sc.nextLine();
		System.out.println("Enter Phone");
		String phone=sc.nextLine();
		System.out.println("Enter Address");
		String add=sc.nextLine();
		System.out.println("************ "+name+" *************");
		System.out.println("************Ph. "+phone+" ************");
		System.out.println("Name:"+cname);
		System.out.println("Phone:"+phone);
		System.out.println("Address:"+add);
		System.out.println("Food Item:"+item);
		System.out.println("\t\t\t Total Amount "+amnt);
		System.out.println("**************************************");	
	}
	
	
}
class ChineseR extends Restaurant{
	private static ChineseR instance = null;
public enum Menu{
	Momos(40),
	ChilliPotatos(70),
	Noodles(100),
	SpringRoll(50);
	private final int price;

    private Menu(int price) {
        this.price = price;
    }
}
private ChineseR(){
	name="China Town";
	phone=9953666666l;
}
static  int check(String a)
    {
    	for (Menu c : Menu.values()) {
            if (c.name().equals(a)) {
                return c.price;
            }
        }
		return 0;
    }
public static ChineseR getInstance()
{
	if(instance==null)
		instance=new ChineseR();
	return instance;
}
}
class NorthIndianR extends Restaurant{
	private static NorthIndianR instance = null;
public enum Menu{
	CholeBhature(100),
	GolGappe(70),
	kulcha(100);
	private final int price;

    private Menu(int price) {
        this.price = price;
    }
}
private NorthIndianR(){
	name="Pind Baluchi";
	phone=986796866l;
}
static int check(String a)
{
	for (Menu c : Menu.values()) {
        if (c.name().equals(a)) {
            return c.price;
        }
    }
	return 0;
}
public static NorthIndianR getInstance()
{
	if(instance==null)
		instance=new NorthIndianR();
	return instance;
}
}
class SouthIndianR extends Restaurant{
	private static SouthIndianR instance = null;
public enum Menu{
	Idli(40),
	Uttpam(70),
	Dosa(100);
	private final int price;

    private Menu(int price) {
        this.price = price;
    }
}
private SouthIndianR(){
	name="Sagar Ratna";
	phone=9777666666l;
}
static int check(String a)
{
	for (Menu c : Menu.values()) {
        if (c.name().equals(a)) {
            return c.price;
        }
    }
	return 0;
}
public static SouthIndianR getInstance()
{
	if(instance==null)
		instance=new SouthIndianR();
	return instance;
}
}








