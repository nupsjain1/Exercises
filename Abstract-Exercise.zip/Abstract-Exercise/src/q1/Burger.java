package q1;


import java.util.Scanner;
public class Burger {
	static int count=0;
	String type;
	final int price;
	int quantity;
	String size;
	Burger(String type,String size,int quantity)
	{
		this.type=type;
		this.size=size;
		this.quantity=quantity;
		count=count+quantity;
		if(type.equals("veg"))
		{
			if(size.equals("large"))
				price=50;
			else
				price=30;
		}
		else{
			if(size.equals("large"))
				price=80;
			else
				price=50;
		}
			
		
	}
	public void  show(){
		System.out.println("You Purchased "+quantity+" "+type+" burger for Rs. "+quantity*price);
		
	}
	

	public static void main(String[] args) {
		char c;
		do{
			Scanner sc=new Scanner(System.in); 
		System.out.println("veg/nonveg");
		String s=sc.nextLine();
		System.out.println("large/small");
		String t=sc.nextLine();
		System.out.println("Quantity");
		int q=sc.nextInt();
		new Burger(s,t,q).show();
			System.out.println("Do you want to buy more y/n"); 
			c=sc.next().charAt(0); 
		}while(c=='y'||c=='Y'); 
		System.out.println("No. of Burgers Sold: "+Burger.count);
	}

}

